package pe.edu.upc.aww.takemehome0_0;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TakemeHome00Application {

    public static void main(String[] args) {
        SpringApplication.run(TakemeHome00Application.class, args);
    }

}
