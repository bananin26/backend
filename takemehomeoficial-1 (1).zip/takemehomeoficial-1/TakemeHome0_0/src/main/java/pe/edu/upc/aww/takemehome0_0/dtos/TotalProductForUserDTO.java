package pe.edu.upc.aww.takemehome0_0.dtos;

public class TotalProductForUserDTO {

    private String name;
    private int totalProducts;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public int getTotalProducts() {
        return totalProducts;
    }

    public void setTotalProducts(int totalProducts) {
        this.totalProducts = totalProducts;
    }
}
